import csv
import tkinter as tk

def average_price(product_rows):
    prices = [float(row[2]) for row in product_rows if float(row[3]) > 0]
    if len(prices) == 0:
        return None
    return sum(prices) / len(prices)

def calculate_average_prices():
    result_text.delete("1.0", tk.END)  # очистить содержимое виджета Text перед выводом новых результатов
    for product_name, product_rows in product_dict.items():
        avg_price = average_price(product_rows)
        if avg_price is not None:
            result_text.insert(tk.END, f"Average price of {product_name}: {avg_price:.2f}\n")

data = []
with open('lahjadata.csv', newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter=',')
    for row in reader:
        data.append(row)

# Сортировка данных по названию продукта и типу продукта
sorted_data = sorted(data, key=lambda x: (x[0], x[1]))

# Создание словаря, в котором ключами являются названия продуктов,
# а значениями - списки строк, соответствующие каждому продукту
product_dict = {}
for row in sorted_data:
    product_name = row[0]
    if product_name in product_dict:
        product_dict[product_name].append(row)
    else:
        product_dict[product_name] = [row]

root = tk.Tk()
root.title("Olen yllättynyt, että se toimii")
root.geometry("400x400")

# создание виджета Text для вывода списка и результатов
list_text = tk.Text(root, height=10)
list_text.pack(fill=tk.BOTH, expand=True)
result_text = tk.Text(root, height=10)
result_text.pack(fill=tk.BOTH, expand=True)

# вывод списка в виджет Text
for product_name, product_rows in product_dict.items():
    list_text.insert(tk.END, f"{product_name}\n")
    for row in product_rows:
        list_text.insert(tk.END, f"\t{' '.join(row)}\n")

# создание кнопки для вычисления средних цен
button = tk.Button(root, text="Calculate average prices", command=calculate_average_prices, bg = "red")
button.pack()

root.mainloop()



        
        

        
        
